package TM04_Proj1;
public abstract class Account {
	double interestRate;
	double amount;
	abstract double calculateInterest();
}
